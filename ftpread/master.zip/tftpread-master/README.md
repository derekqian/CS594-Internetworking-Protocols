# tftpread
Copyright © 2012 Bart Massey

This is a simple tftp reader client.  The tftpread program
accepts two command-line arguments: the hostname to fetch
from and the pathname to fetch. The program writes the
fetched file to stdout.

This client is intended as a network programming demo. As
such, it is not very robust or complete. Caveat emptor.

This program is licensed under the "MIT License".  Please
see the file COPYING in the source distribution of this
software for license terms.
